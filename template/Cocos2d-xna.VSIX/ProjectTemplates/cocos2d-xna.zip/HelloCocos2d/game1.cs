using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Input.Touch;
using Microsoft.Xna.Framework.Media;
using cocos2d;
$if$ ($CreateWithOpenxlive$ == True)
using OpenXLive;
using OpenXLive.Forms;
$endif$

namespace $SolutionName$
{
    $if$ ($CreateWithOpenxlive$ == True)

    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        CCApplication application;

        //#error Please full your game Secret Key in below code
        private string APISecretKey = "xxxxxxxxxxxxxxxxxxxxxxxxxxxx";

        public static XLiveFormManager manager;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";

            graphics.IsFullScreen = true;

            // Frame rate is 30 fps by default for Windows Phone.
            TargetElapsedTime = TimeSpan.FromTicks(333333);

            // Extend battery life under lock.
            InactiveSleepTime = TimeSpan.FromSeconds(1);

            application = new AppDelegate(this, graphics);
            this.Components.Add(application);
        }

        protected override void Initialize()
        {
            // Create XLive FormManager
            manager = new XLiveFormManager(this, APISecretKey);
            Game1.manager.OpenSession();

            // Add XLive FormManager in Components
            Components.Add(manager);

            base.Initialize();
        }

        protected override void LoadContent()
        {
            Texture2D background = this.Content.Load<Texture2D>("OpenXLive");

            XLiveStartupForm form = new XLiveStartupForm(manager);
            form.Background = background;
            form.AnimationIntervalSeconds = 0;
            form.AnimationSpeed = 5;
            form.BackgroundAnimation = true;
            form.Show();
        }

        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
            {
                if (manager.IsRunning)
                {
                    XLivePauseForm form = new XLivePauseForm(manager);
                    form.Show();
                }
            }

            if (manager.IsRunning)
            {
                // TODO: Add your update logic here
            }

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            if (CCDirector.sharedDirector().isPaused)
            {
                this.Components.Remove(application);
                if (manager.IsRunning)
                {
                    GraphicsDevice.Clear(Color.CornflowerBlue);

                    // TODO: Add your drawing code here
                }
            }
            else
            {
                manager.StartGame();
            }

            base.Draw(gameTime);
        }
    }

    $endif$

    $if$ ($CreateWithOpenxlive$ == False)

    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        CCApplication application;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";

            graphics.IsFullScreen = true;

            // Frame rate is 30 fps by default for Windows Phone.
            TargetElapsedTime = TimeSpan.FromTicks(333333);

            // Extend battery life under lock.
            InactiveSleepTime = TimeSpan.FromSeconds(1);

            application = new AppDelegate(this, graphics);
            this.Components.Add(application);
        }
    }

    $endif$
}
