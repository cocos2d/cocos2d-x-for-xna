using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using cocos2d;

namespace $SolutionName$
{
    public class $SolutionName$Scene : CCLayer
    {
        /// <summary>
        ///  Here's a difference. Method 'init' in cocos2d-x returns bool, instead of returning 'id' in cocos2d-iphone
        /// </summary>
        public override bool init()
        {
            CCDirector.sharedDirector().deviceOrientation = ccDeviceOrientation.CCDeviceOrientationLandscapeLeft;

            //////////////////////////////
            // 1. super init first
            if (!base.init())
            {
                return false;
            }

            // ask director the window size
            CCSize size = CCDirector.sharedDirector().getWinSize();
            this.m_bIsTouchEnabled = true;

            /////////////// //////////////
            // 2. add a menu item with "X" image, which is clicked to quit the program
            //    you may modify it.

            // add a "close" icon to exit the progress. it's an autorelease object
            CCMenuItemImage pCloseItem = CCMenuItemImage.itemFromNormalImage(
                                                "CloseNormal",
                                                "CloseSelected",
                                                this, menuCloseCallback);
            pCloseItem.position = new CCPoint(CCDirector.sharedDirector().getWinSize().width - 20, 20);

            $if$ ($CreateWithOpenxlive$ == True)

            CCLabelTTF pOpenxliveLabel = CCLabelTTF.labelWithString("Openxlive", "Arial", 12);
            CCMenuItemLabel pOpenxliveItem = CCMenuItemLabel.itemWithLabel(pOpenxliveLabel, this, menuOpenxliveCallback);
            pOpenxliveItem.position = new CCPoint(120, 30);

            // create menu, it's an autorelease object
            CCMenu pMenu = CCMenu.menuWithItems(pCloseItem, pOpenxliveItem);
            pMenu.position = new CCPoint(0, 0);
            this.addChild(pMenu, 1);

            $endif$

            $if$ ($CreateWithOpenxlive$ == False)

            // create menu, it's an autorelease object
            CCMenu pMenu = CCMenu.menuWithItems(pCloseItem);
            pMenu.position = new CCPoint(0, 0);
            this.addChild(pMenu, 1);

            $endif$

            /////////////////////////////
            // 3. add your codes below...

            // add a label shows "Hello World"
            // create and initialize a label
            CCLabelTTF pLabel = CCLabelTTF.labelWithString("Hello World", "Arial", 24);

            // position the label on the center of the screen
            pLabel.position = new CCPoint(size.width / 2, size.height - 50);

            // add the label as a child to this layer
            this.addChild(pLabel, 1);

            // add "HelloWorld" splash screen"
            CCSprite pSprite = CCSprite.spriteWithFile("HelloWorld");

            // position the sprite on the center of the screen
            pSprite.position = new CCPoint(size.width / 2, size.height / 2);

            // add the sprite as a child to this layer
            this.addChild(pSprite, 0);

            return true;
        }
        CCSprite pSprite;
        /// <summary>
        /// there's no 'id' in cpp, so we recommand to return the exactly class pointer
        /// </summary>
        public static CCScene scene()
        {
            // 'scene' is an autorelease object
            CCScene scene = CCScene.node();

            // 'layer' is an autorelease object
            CCLayer layer = $SolutionName$Scene.node();

            // add layer as a child to scene
            scene.addChild(layer);

            // return the scene
            return scene;
        }

        public static new CCLayer node()
        {
            $SolutionName$Scene ret = new $SolutionName$Scene();
            if (ret.init())
            {
                return ret;
            }
            else
            {
                ret = null;
            }

            return ret;
        }

        /// <summary>
        /// a selector callback
        /// </summary>
        /// <param name="pSender"></param>
        public virtual void menuCloseCallback(CCObject pSender)
        {
            CCDirector.sharedDirector().end();
            CCApplication.sharedApplication().Game.Exit();
        }

        $if$ ($CreateWithOpenxlive$ == True)

        public void menuOpenxliveCallback(CCObject pSender)
        {
            CCDirector.sharedDirector().pause();
            Game1.manager.PauseGame();
        }

        $endif$
    }
}
