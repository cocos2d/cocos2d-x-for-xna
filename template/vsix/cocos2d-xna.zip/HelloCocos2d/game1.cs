using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Input.Touch;
using Microsoft.Xna.Framework.Media;
using cocos2d;
$if$ ($CreateWithOpenxlive$ == True)
using OpenXLive;
$endif$

namespace $SolutionName$
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        CCApplication application;
        $if$ ($CreateWithOpenxlive$ == True)
        //#error Please full your game Secret Key in below code
        private string APISecretKey = "Y8eUF6f5xXEGSuw3DkKntbhQ";

        XLiveFormManager manager;
        $endif$
        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";

            this.graphics.IsFullScreen = true;

            // Frame rate is 30 fps by default for Windows Phone.
            TargetElapsedTime = TimeSpan.FromTicks(333333);

            // Extend battery life under lock.
            InactiveSleepTime = TimeSpan.FromSeconds(1);
             $if$ ($CreateWithOpenxlive$ == True)
            // Create XLive FormManager
            manager = new XLiveFormManager(this, APISecretKey);
            manager.OpenSession();

            // Add XLive FormManager in Components
            Components.Add(manager);
            $endif$
            CCApplication application = new AppDelegate(this, graphics);
            this.Components.Add(application);
        }

        protected override void LoadContent()
        {
            $if$ ($CreateWithOpenxlive$ == True)
            Texture2D background = this.Content.Load<Texture2D>(@"images\OpenXLive");

            manager.Background = background;
            manager.UIExitingEvent += new EventHandler(manager_UIExiting);
            $endif$
            base.LoadContent();
        }

        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();

            // TODO: Add your update logic here


            base.Update(gameTime);
        }
        $if$ ($CreateWithOpenxlive$ == True)
        void manager_UIExiting(object sender, EventArgs e)
        {
            CCDirector.sharedDirector().runningScene.visible = true;
        }
        $endif$
    }
}
